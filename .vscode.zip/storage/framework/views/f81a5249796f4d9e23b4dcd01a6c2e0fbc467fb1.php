<?php $__env->startSection('subItem','Proveedores'); ?>

<?php $__env->startSection('nombre'); ?>
	<?php echo e(session('usuario')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('rol'); ?>
	<?php echo e(session('rol')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('sede'); ?>

	<?php echo e(session('sede')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="css/proveedor.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>




<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addpr"><i class="fa fa-plus-circle" aria-hidden="true"></i>
  Nuevo
</button>
<br><br>

<!-- Modal -->
<div class="modal fade" id="addpr" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="exampleModalCenterTitle"> <i class="fa fa-file" aria-hidden="true"></i> NUEVO PROVEEDOR</h5>
        <button type="button" class="close" id="cerraradd" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

       <form id="frmadd">
            <div class="modal-body">
           

            <input type="text" name="" id="token" hidden="" value="<?php echo e(csrf_token()); ?>">
            
            <div class="form-group">
            <label for="Nombre">Nombre</label>
            <input type="text" class="form-control" id="nombre" name="nombre" aria-describedby="emailHelp" placeholder="Nombre" required="">
            </div>

			<div class="form-group">
			<label for="ruc">Ruc</label>
			<input type="number" class="form-control" id="ruc" name="ruc" aria-describedby="emailHelp" placeholder="ruc" required="">
			</div>

			<div class="form-group">
			<label for="telefono">Telefono</label>
			<input type="number" class="form-control" id="telefono" name="telefono" aria-describedby="emailHelp" placeholder="telefono" required="">
			</div>

			<div class="form-group">
			<label for="email">Email</label>
			<input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="email" required="">
			</div>

			<div class="form-group">
			<label for="direccion">Direccion</label>
			<input type="direccion" class="form-control" id="direccion" name="direccion" aria-describedby="emailHelp" placeholder="direccion" required="">
			 <small id="telefono" class="form-text text-muted">campo opcional</small>
			</div>
			<input type="text" name="" id="idsede" hidden="" value="" idsede='<?php echo e(session('idsede')); ?>'>




            <button type ="button" class="btn btn-success" id="btnAdd"><i class="fa fa-floppy-o" aria-hidden="true"> Guardar</i></button>
            
            </div>
     
      </form>

    

    </div>
  </div>
</div>

<!-- Modal edit -->
<div class="modal fade" id="editpr" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="exampleModalCenterTitle"> <i class="fa fa-file" aria-hidden="true"></i> EDITAR PROVEEDOR</h5>
        <button type="button" class="close" id="cerrarEdit" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

       <form id="frmadd">
            <div class="modal-body">
           

            <input type="text" name="" id="tokenup" hidden="" value="<?php echo e(csrf_token()); ?>">
            
            <div class="form-group">
            <label for="Nombre">Nombre</label>
            <input type="text" class="form-control" id="nombreup" name="nombre" aria-describedby="emailHelp" placeholder="Nombre" required="">
            </div>

			<div class="form-group">
			<label for="ruc">Ruc</label>
			<input type="number" class="form-control" id="rucup" name="ruc" aria-describedby="emailHelp" placeholder="ruc" required="">
			</div>

			<div class="form-group">
			<label for="telefono">Telefono</label>
			<input type="number" class="form-control" id="telefonoup" name="telefono" aria-describedby="emailHelp" placeholder="telefono" required="">
			</div>

			<div class="form-group">
			<label for="email">Email</label>
			<input type="email" class="form-control" id="emailup" name="email" aria-describedby="emailHelp" placeholder="email" required="">
			</div>

			<div class="form-group">
			<label for="direccion">Direccion</label>
			<input type="direccion" class="form-control" id="direccionup" name="direccion" aria-describedby="emailHelp" placeholder="direccion" required="">
			
			</div>
			<input type="text" name="" id="idsedeup" hidden="" >
			<input type="text" name="" id="idproveedorup" hidden="" >




            <button type ="button" class="btn btn-success" id="btnUp"><i class="fa fa-floppy-o" aria-hidden="true"> Actualizar</i></button>
            
            </div>
     
      </form>

    

    </div>
  </div>
</div>











<div class="table-responsive">
<table class="table table-hover" id="tableData">
 <thead class="thead-dark">
    <tr>
     
      <th scope="col">Nombre</th>
      <th scope="col">Ruc</th>
      <th scope="col">Telefono</th>
       <th scope="col">Direccion</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody id="tableb">  
  <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    
      <td data-label="Nombre"><?php echo e($value->nombre); ?></td>
      <td data-label="Ruc"><?php echo e($value->ruc); ?></td>
      <td data-label="Telefono"><?php echo e($value->telefono); ?></td>
      <td data-label="Direccion"><?php echo e($value->direccion); ?></td>
      <td>
       
		<button data-toggle ="modal" class="btn btn-warning"  data-target="#editpr" id="btnEdit" idpro='<?php echo e($value->idproveedor); ?>'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>

		<button id="btnDelete" class="btn btn-danger" tokende="<?php echo e(csrf_token()); ?> "  idcateDel="<?php echo e($value->idproveedor); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
		
		<button id="btnDetalles" class="btn btn-info" iddetalle="<?php echo e($value->idproveedor); ?>"><i class="fa fa-eye" aria-hidden="true"></i></button>
		</td>
    </tr> 
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  </tbody>
</table>
</div>


	

<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido-derecho'); ?>

<br><br><br><br>

   
 


		<div class="card text-center" id="cardDetalle" style="display: none" >
		<div class="card-header" style="background:">
		Detalles
		<button type="button" class="close" id="btncloseDe">
		<span aria-hidden="true">&times;</span>
		</button>
		</div>
		<div class="card-body" style="background:">

				<div><span></span> <b style="font-size: 20px;color: " class="" id="nombredeta"></b style="font-size: 20px;color:"></div>
				<div><span style="color: ">Ruc:       </span> <span class="" id="rucdeta"></span></div>
				<div><span style="color: ">Telefono:  </span> <span class="" id="telefonodeta"></span></div>
				<div><span style="color: ">Direccion: </span> <span class="" id="direcciondeta"></span></div>
		
		</div>
		<div class="card-footer text-muted">
		<span id="emaildeta" ></span>
		</div>
		</div>

  

<?php $__env->stopSection(); ?>




<?php $__env->startSection('scripts'); ?>
 <script type="text/javascript" src="js/proveedor.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantilla3.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>