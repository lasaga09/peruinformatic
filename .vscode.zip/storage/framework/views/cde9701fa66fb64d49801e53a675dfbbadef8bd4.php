<?php $__env->startSection('subItem','Categorias'); ?>

<?php $__env->startSection('nombre'); ?>
  <?php echo e(session('usuario')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('rol'); ?>
  <?php echo e(session('rol')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('sede'); ?>

  <?php echo e(session('sede')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>








  

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter"><i class="fa fa-plus-circle" aria-hidden="true"></i>
  Nuevo
</button>







<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="exampleModalCenterTitle"> <i class="fa fa-file" aria-hidden="true"></i> NUEVA CATEGORIA</h5>
        <button type="button" class="close" id="cerraradd" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

       <form>
            <div class="modal-body">
           

            <input type="text" name="" id="token" hidden="" value="<?php echo e(csrf_token()); ?>">
            
            <div class="form-group">
            <label for="categoria">Nombre de la categoria</label>
            <input type="text" class="form-control" id="categoria" name="categoria" aria-describedby="emailHelp" placeholder="Nombre" required="">
            <small id="categoriaValidacion" class="form-text text-muted"></small>
            </div>
            
            <div class="form-group">
            <label for="descipcion">Descripcion</label>
            <input type="text" class="form-control" id="descripcion" name="descripcion" aria-describedby="emailHelp" placeholder="descripcion" required="">
            <small id="telefono" class="form-text text-muted">campo opcional</small>
            </div>
            
            <button type ="button" class="btn btn-success" id="btnAdd"><i class="fa fa-floppy-o" aria-hidden="true"> Guardar</i></button>
            
            </div>
     
      </form>

    

    </div>
  </div>
</div>


<!-- Modal edit -->
<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="exampleModalCenterTitle"> <i class="fa fa-file" aria-hidden="true"></i> EDITAR CATEGORIA</h5>
        <button type="button" class="close" id="cerrarEdit" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

       <form id="frmadd">
            <div class="modal-body">
           

            <input type="text" name="" id="tokenup" hidden="" value="<?php echo e(csrf_token()); ?>">
            <input type="text" name="" id="idcateup" hidden="">
            
            <div class="form-group">
            <label for="categoria">Nombre de la categoria</label>
            <input type="text" class="form-control" id="categoriaup" name="categoria" aria-describedby="emailHelp" required="">
            <small id="categoriaValidacion" class="form-text text-muted"></small>
            </div>
            
            <div class="form-group">
            <label for="descipcion">Descripcion</label>
            <input type="text" class="form-control" id="descripcionup" name="descripcion" aria-describedby="emailHelp" required="">
      
            </div>
            
            <button type ="button" class="btn btn-success" id="btnUpdate"><i class="fa fa-floppy-o" aria-hidden="true"> Actualizar</i></button>
            
            </div>
     
      </form>

    

    </div>
  </div>
</div>






<br><br>
<table class="table table-hover" id="tableData">
 <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nobre</th>
      <th scope="col">descripcion</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody id="tbody">  
  
        
        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td scope="row"><?php echo e($value->idcategoria); ?></td>
        <td id="tnombre"><?php echo e($value->nombre); ?></td>
        <td id="tdescripcion"><?php echo e($value->descripcion); ?></td>
        <td>
        
        <button data-toggle="modal" class="btn btn-warning" ss='66' data-target="#edit" id="btnEdit" idcate='<?php echo e($value->idcategoria); ?>'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
        <button class="btn btn-danger" id="btnDelete" tokende="<?php echo e(csrf_token()); ?> "  idcateDel="<?php echo e($value->idcategoria); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
        </td>
        </tr> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

   
   
  </tbody>
</table>








<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido-derecho'); ?>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('scripts'); ?>
 <script type="text/javascript" src="js/categoria.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantilla3.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>