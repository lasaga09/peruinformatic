<?php $__env->startSection('subItem','Gestionar Usuarios'); ?>
<?php $__env->startSection('subItem2','Rol'); ?>
<?php $__env->startSection('nombre'); ?>
	<?php echo e(session('usuario')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('rol'); ?>
	<?php echo e(session('rol')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('sede'); ?>

	<?php echo e(session('sede')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter"><i class="fa fa-plus-circle" aria-hidden="true"></i>
  Nuevo
</button>
<br>
<br>


<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="exampleModalCenterTitle"> <i class="fa fa-file" aria-hidden="true"></i></h5>
        <button type="button" class="close" id="cerraradd" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

       <form id="frmadd">
            <div class="modal-body">
           

            <input type="text" name="" id="token" hidden="" value="<?php echo e(csrf_token()); ?>">
            
            <div class="form-group">
            <label for="rol">Rol</label>
            <input type="text" class="form-control" id="rol" name="rol" aria-describedby="emailHelp" placeholder="Rol" required="">
            <small id="categoriaValidacion" class="form-text text-muted"></small>
            </div>
            
            <div class="form-group">
            <label for="descipcion">Descripcion</label>
            <input type="text" class="form-control" id="descripcion" name="descripcion" aria-describedby="emailHelp" placeholder="descripcion" required="">
            <small id="telefono" class="form-text text-muted">campo opcional</small>
            </div>
            
            <button type ="button" class="btn btn-success" id="btnAdd"><i class="fa fa-floppy-o" aria-hidden="true"> Guardar</i></button>
            
            </div>
     
      </form>

    

    </div>
  </div>
</div>


	
	<table class="table table-hover" id="tableData">
 <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombre</th>
      <th scope="col">descripcion</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody id="tableb">  
  <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
      <td scope="row"><?php echo e($value->idrol); ?></td>
      <td><?php echo e($value->rol); ?></td>
      <td><?php echo e($value->descripcion); ?></td>
      <td>
       
       <button data-toggle ="modal" class="btn btn-warning"  data-target="#edit" id="btnEdit" idcate='<?php echo e($value->idrol); ?>'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
       <button id          ="btnDelete" class="btn btn-danger" tokende="<?php echo e(csrf_token()); ?> "  idcateDel="<?php echo e($value->idrol); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
    </td>
      </td>
    </tr> 
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  </tbody>
</table>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido-derecho'); ?>
<br><br><br><br>

<div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Importante!</h4>
  <p>Al eliminar un rol afectara el proceso de usuario con respectivo rol</p>
  <hr>
  <p class="mb-0"><b>Recomendacion  </b> No Elimine un rol si tiene usuarios agregados al rol</p>
</div>
<div class="alert alert-primary" role="alert">
  Revisar  <a href="Usuario" class="alert-link">Usuarios</a>. 
Dale un click para administrar usuarios.
</div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('scripts'); ?>
 <script type="text/javascript" src="js/rol.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantilla3.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>