<?php $__env->startSection('subItem','Home'); ?>
<?php $__env->startSection('subItem2','Principal'); ?>




<?php $__env->startSection('nombre'); ?>
	<?php echo e(session('usuario')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('rol'); ?>
	<?php echo e(session('rol')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('sede'); ?>

	<?php echo e(session('sede')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido-cabezera'); ?>
 <?php if(session('idrol') == 1 or session('idrol') == 2 ): ?>
          <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo e($tusuario); ?></h3>
                <p>Usuarios registrado</p>
              </div>
              <div class="icon">
                <i class="fa fa-users" aria-hidden="true"></i>
              </div>
              <a href="Usuario" class="small-box-footer">Ir a Usuarios <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <?php endif; ?>
      


      
          <?php if(session('permisos')->pcliente == 0): ?>
            <div class="col-lg-3 col-6">
              <div class="small-box bg-success" id="Vcli">
                <div class="inner">
                  <h3><?php echo e($tcliente); ?></h3>
                  <p>Clientes registrados</p>
                </div>
                <div class="icon">
                  <i class="fa fa-users" aria-hidden="true"></i>
                </div>
                <a href="Cliente"  class="small-box-footer" style="pointer-events:none;
                cursor: pointer;">ir a clientes <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div>
          <?php else: ?>
            <div class="col-lg-3 col-6" style="display:;">
              <div class="small-box bg-success">
                <div class="inner">
                  <h3><?php echo e($tcliente); ?></h3>
                  <p>Clientes registrados</p>
                </div>
                <div class="icon">
                  <i class="fa fa-users" aria-hidden="true"></i>
                </div>
                <a href="Cliente" class="small-box-footer">ir a clientes <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div>


          <?php endif; ?>






 <?php if(session('permisos')->pproveedores == 0): ?>
        
        <div class="col-lg-3 col-6">
          <div class="small-box bg-warning">
            <div class="inner">
              <h3><?php echo e($tproveedor); ?></h3>
              <p>Proveedores Registrado</p>
            </div>
            <div class="icon">
              <i class="fa fa-car" aria-hidden="true"></i>
            </div>
            <a href="Proveedor" style="pointer-events:none;
            cursor: pointer;" class="small-box-footer">ir a proveedores <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
    <?php else: ?>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php echo e($tproveedor); ?></h3>
                <p>Proveedores Registrado</p>
              </div>
              <div class="icon">
                <i class="fa fa-car" aria-hidden="true"></i>
              </div>
              <a href="Proveedor" class="small-box-footer">ir a proveedores <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

    <?php endif; ?>








<?php if(session('permisos')->pproductos == 0): ?>
          <div class="col-lg-3 col-6">
            <div class="small-box bg-danger"  id="Vpro">
              <div class="inner">
                <h3 style="color:#DC3545">65</h3>
                <p>Productos</p>
              </div>
              <div class="icon">
                <i class="fa fa-product-hunt" aria-hidden="true"></i>
              </div>
              <a href="#" style="pointer-events:none;
              cursor: pointer;" class="small-box-footer">ir a productos <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
      <?php else: ?>
            <div class="col-lg-3 col-6">
              <div class="small-box bg-danger">
                <div class="inner">
                  <h3 style="color:#DC3545">65</h3>
                  <p>Productos</p>
                </div>
                <div class="icon">
                  <i class="fa fa-product-hunt" aria-hidden="true"></i>
                </div>
                <a href="#" class="small-box-footer">ir a productos <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div>

  <?php endif; ?>







<?php if(session('permisos')->pventa == 0): ?>

            <div class="col-lg-3 col-6">
              <div class="small-box bg-info" id="Vven">
                <div class="inner">
                  <h3>150</h3>
                  <p>Ventas</p>
                </div>
                <div class="icon">
                  <i class="ion ion-bag"></i>
                </div>
                <a href="#" style="pointer-events:none;
                cursor: pointer;" class="small-box-footer">ir a ventas <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div>

    <?php else: ?>
              <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                  <div class="inner">
                    <h3>150</h3>
                    <p>Ventas</p>
                  </div>
                  <div class="icon">
                    <i class="ion ion-bag"></i>
                  </div>
                  <a href="#" class="small-box-footer">ir a ventas <i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div>


  <?php endif; ?>






<?php if(session('permisos')->pconsultas == 0): ?>
       
                <div class="col-lg-3 col-6">
                  <div class="small-box bg-success" id="Vcon">
                    <div class="inner">
                      <h3>53<sup style="font-size: 20px">%</sup></h3>
                      <p>Consultas</p>
                    </div>
                    <div class="icon">
                      <i class="ion ion-stats-bars"></i>
                    </div>
                    <a href="#" style="pointer-events:none;
                    cursor: pointer;" class="small-box-footer">ir a consultas <i class="fa fa-arrow-circle-right"></i></a>
                  </div>
                </div>
        <?php else: ?>

                <div class="col-lg-3 col-6">
                  <div class="small-box bg-success">
                    <div class="inner">
                      <h3>53<sup style="font-size: 20px">%</sup></h3>
                      <p>Consultas</p>
                    </div>
                    <div class="icon">
                      <i class="ion ion-stats-bars"></i>
                    </div>
                    <a href="#" class="small-box-footer">ir a consultas <i class="fa fa-arrow-circle-right"></i></a>
                  </div>
                </div>
   
      <?php endif; ?>





         
    

         

    <?php if(session('permisos')->pcompra == 0): ?>
                <div class="col-lg-3 col-6">
                  <div class="small-box bg-warning" id="Vconpra">
                    <div class="inner">
                      <h3>65</h3>
                      <p>Compras</p>
                    </div>
                    <div class="icon">
                      <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                    </div>
                    <a href="#" style="pointer-events:none;
                    cursor: pointer;" class="small-box-footer">ir compras <i class="fa fa-arrow-circle-right"></i></a>
                  </div>
                </div>
      <?php else: ?>
                  <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                      <div class="inner">
                        <h3>65</h3>
                        <p>Compras</p>
                      </div>
                      <div class="icon">
                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                      </div>
                      <a href="#" class="small-box-footer">ir compras <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                  </div>


    <?php endif; ?>





<?php if(session('permisos')->preporte == 0): ?>
            <div class="col-lg-3 col-6">
              <div class="small-box bg-info" id="Vrepo">
                <div class="inner">
                  <h3>150</h3>
                  <p>Reportes</p>
                </div>
                <div class="icon">
                  <i class="ion ion-bag"></i>
                </div>
                <a href="#" style="pointer-events:none;
                cursor: pointer;" class="small-box-footer">ir reportes <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div>

    <?php else: ?>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h3>150</h3>
                <p>Reportes</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">ir reportes <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

    <?php endif; ?>
  

      
           

       
       
         
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	
<h5>pantallas principal</h5>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="js/validarhome.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantilla3.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>