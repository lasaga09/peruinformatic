<table class="table table-hover" id="tableData">
 <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nobre</th>
      <th scope="col">descripcion</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody id="tableb">  
  <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
      <td scope="row"><?php echo e($value->idcategoria); ?></td>
      <td><?php echo e($value->nombre); ?></td>
      <td><?php echo e($value->descripcion); ?></td>
      <td>
       
        <button data-toggle="modal" ss='66' data-target="#edit" id="btnEdit" idcate='<?php echo e($value->idcategoria); ?>'>edit</button>
        <button id="btnDelete" tokende="<?php echo e(csrf_token()); ?> "  idcateDel="<?php echo e($value->idcategoria); ?>">x</button>
      </td>
    </tr> 
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  </tbody>
</table>


