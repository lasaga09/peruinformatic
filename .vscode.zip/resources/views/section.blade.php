
@extends('Plantilla3.index')
@section('subItem','Clientes')

@section('nombre')
	{{session('usuario')}}
@endsection

@section('rol')
	{{session('rol')}}
@endsection
@section('sede')

	{{session('sede')}}
@endsection

@section('contenido')
	

@endsection


@section('contenido-derecho')


@endsection




@section('scripts')
 
@endsection