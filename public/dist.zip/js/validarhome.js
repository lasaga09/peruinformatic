/*$(document).ready(function(){


 
  var validarCli = document.getElementById("Vcli");

  validarCli.addEventListener('click',function(){
alertify.set('notifier','position', 'top-center');
 alertify.error('Opcion Deshabilitada  !!!');
  });

   var validarPro = document.getElementById("Vpro");
  validarPro.addEventListener('click',function(e){
alertify.set('notifier','position', 'top-center');
 alertify.error('Opcion Deshabilitada  !!!');
  });

    var validarVen = document.getElementById("Vven");
  validarVen.addEventListener('click',function(e){
alertify.set('notifier','position', 'top-center');
 alertify.error('Opcion Deshabilitada  !!!');
  });

  var validarCon = document.getElementById("Vcon");
  validarCon.addEventListener('click',function(e){
alertify.set('notifier','position', 'top-center');
 alertify.error('Opcion Deshabilitada  !!!');
  });

   var validarCompra = document.getElementById("Vconpra");
  validarCompra.addEventListener('click',function(e){
alertify.set('notifier','position', 'top-center');
 alertify.error('Opcion Deshabilitada  !!!');
  });
 var validarReport = document.getElementById("Vrepo");
  validarReport.addEventListener('click',function(e){
alertify.set('notifier','position', 'top-center');
 alertify.error('Opcion Deshabilitada  !!!');
  });



})*/